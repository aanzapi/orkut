const crypto = require('crypto');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const FormData = require('form-data');
const QRCode = require('qrcode');

function convertCRC16(str) {
    let crc = 0xFFFF;
    for (let c = 0; c < str.length; c++) {
        crc ^= str.charCodeAt(c) << 8;
        for (let i = 0; i < 8; i++) {
            if (crc & 0x8000) {
                crc = (crc << 1) ^ 0x1021;
            } else {
                crc = crc << 1;
            }
        }
    }
    let hex = crc & 0xFFFF;
    hex = ('000' + hex.toString(16).toUpperCase()).slice(-4);
    return hex;
}

function generateTransactionId() {
    return 'AZX-' + crypto.randomBytes(3).toString('hex').toUpperCase();
}

function generateExpirationTime() {
    const exp = new Date();
    exp.setMinutes(exp.getMinutes() + 30);
    return exp.toISOString().replace('T', ' ').slice(0, 19);
}

async function uploadToPixhost(imageBuffer) {
    const url = 'https://api.pixhost.to/images';
    const form = new FormData();
    form.append('content_type', '0');
    form.append('img', imageBuffer, 'qr.png');

    const response = await axios({
        method: 'POST',
        url: url,
        data: form,
        headers: {
            ...form.getHeaders(),
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        },
        timeout: 30000,
    });

    if (response.status !== 200) {
        throw new Error(`Pixhost upload HTTP ${response.status}`);
    }

    const data = response.data;
    if (!data || !data.show_url) {
        throw new Error('Pixhost response tidak valid');
    }

    // Follow show_url to get direct image URL
    const htmlResponse = await axios({
        method: 'GET',
        url: data.show_url,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
        },
        timeout: 15000,
        maxRedirects: 5,
    });

    const html = htmlResponse.data;
    const match = html.match(/<img[^>]+class="image-img"[^>]+src="([^"]+)"/i);
    if (!match) {
        throw new Error('Tidak dapat menemukan URL gambar');
    }

    let directUrl = match[1];
    if (directUrl.startsWith('//')) {
        directUrl = 'https:' + directUrl;
    } else if (directUrl.startsWith('/')) {
        directUrl = 'https://pixhost.to' + directUrl;
    }
    return directUrl;
}

async function uploadToUploadCC(imageBuffer) {
    const url = 'https://upload.cc/image_upload';
    const form = new FormData();
    form.append('uploaded_file[]', imageBuffer, 'qr.png');

    const response = await axios({
        method: 'POST',
        url: url,
        data: form,
        headers: {
            ...form.getHeaders(),
            'Referer': 'https://upload.cc',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
        },
        timeout: 30000,
    });

    if (response.status !== 200) {
        throw new Error(`Upload.cc HTTP ${response.status}`);
    }

    const data = response.data;
    if (!data || data.code !== 100 || !data.success_image || !data.success_image[0]) {
        throw new Error('Upload.cc response tidak valid');
    }

    const imageUrl = data.success_image[0].url;
    return 'https://upload.cc/' + imageUrl.replace(/^\//, '');
}

async function uploadToTmpNinja(imageBuffer) {
    const url = 'https://tmp.ninja/upload';
    const form = new FormData();
    form.append('file', imageBuffer, 'qr.png');

    const response = await axios({
        method: 'POST',
        url: url,
        data: form,
        headers: form.getHeaders(),
        timeout: 30000,
    });

    if (response.status !== 200) {
        throw new Error(`tmp.ninja HTTP ${response.status}`);
    }

    const data = response.data;
    if (!data || !data.file || !data.file.url) {
        throw new Error('tmp.ninja response tidak valid');
    }
    return data.file.url;
}

async function uploadToCatbox(imageBuffer) {
    const url = 'https://catbox.moe/user/api.php';
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', imageBuffer, 'qr.png');

    const response = await axios({
        method: 'POST',
        url: url,
        data: form,
        headers: form.getHeaders(),
        timeout: 30000,
    });

    if (response.status !== 200) {
        throw new Error(`catbox.moe HTTP ${response.status}`);
    }

    const urlResult = response.data.trim();
    if (!urlResult.startsWith('http')) {
        throw new Error('catbox.moe response bukan URL valid');
    }
    return urlResult;
}

async function uploadImage(imageBuffer) {
    const errors = [];
    
    const uploaders = [
        { name: 'Pixhost', fn: uploadToPixhost },
        { name: 'UploadCC', fn: uploadToUploadCC },
        { name: 'Tmp.ninja', fn: uploadToTmpNinja },
        { name: 'Catbox', fn: uploadToCatbox },
    ];

    for (const uploader of uploaders) {
        try {
            return await uploader.fn(imageBuffer);
        } catch (error) {
            errors.push(`${uploader.name}: ${error.message}`);
        }
    }

    throw new Error(`Semua host gagal: ${errors.join(' | ')}`);
}

async function createQRIS(amount, qrisString) {
    const qrisData = qrisString.slice(0, -4);
    const step1 = qrisData.replace('010211', '010212');
    const parts = step1.split('5802ID');
    const amountStr = amount.toString();
    const uang = '54' + String(amountStr.length).padStart(2, '0') + amountStr + '5802ID';
    const final = parts[0] + uang + parts[1];
    const result = final + convertCRC16(final);

    // Generate QR code
    const qrBuffer = await QRCode.toBuffer(result, {
        width: 400,
        margin: 2,
        type: 'png'
    });

    // Upload to image hosting
    const imageUrl = await uploadImage(qrBuffer);

    return {
        idtransaksi: generateTransactionId(),
        jumlah: amount,
        expired: generateExpirationTime(),
        imageqris: { url: imageUrl },
        qr_string: result
    };
}

module.exports = {
    convertCRC16,
    generateTransactionId,
    generateExpirationTime,
    uploadImage,
    uploadToPixhost,
    uploadToUploadCC,
    uploadToTmpNinja,
    uploadToCatbox,
    createQRIS,
};