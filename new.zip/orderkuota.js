const axios = require('axios');
const crypto = require('crypto');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { v4: uuidv4 } = require('uuid');

class OrderKuota {
    static API_URL = 'https://app.orderkuota.com/api/v2';
    static HOST = 'app.orderkuota.com';
    static USER_AGENT = 'okhttp/4.12.0';
    static KONCI_RAHASIA = 'orderkuota_mobile_app_2024';

    constructor(username = null, authToken = null) {
        this.username = username;
        this.authToken = authToken;
        this.generateDeviceFingerprint();
    }

    generateDeviceFingerprint() {
        const rawUuid = crypto.randomBytes(16).toString('hex');
        this.phoneUuid = [
            rawUuid.substring(0, 8),
            rawUuid.substring(8, 12),
            rawUuid.substring(12, 16),
            rawUuid.substring(16, 20),
            rawUuid.substring(20, 32)
        ].join('-');

        const fcmHash = crypto.createHash('sha256').update(crypto.randomBytes(16)).digest('hex');
        this.appRegId = this.phoneUuid + ':APA91b' + fcmHash.substring(0, 100);

        const phoneModels = ['SM-G973F'];
        this.phoneModel = phoneModels[Math.floor(Math.random() * phoneModels.length)];

        const androidVersions = ['15'];
        this.phoneAndroidVersion = androidVersions[Math.floor(Math.random() * androidVersions.length)];

        const appVersions = ['260115'];
        const appVersionNames = ['26.01.15'];
        const indexApp = Math.floor(Math.random() * appVersions.length);
        this.appVersionCode = appVersions[indexApp];
        this.appVersionName = appVersionNames[indexApp];
    }

    getDeviceInfo() {
        return {
            app_reg_id: this.appRegId,
            phone_uuid: this.phoneUuid,
            phone_model: this.phoneModel,
            phone_android_version: this.phoneAndroidVersion,
            app_version_code: this.appVersionCode,
            app_version_name: this.appVersionName,
        };
    }

    generateSignature(params, timestamp) {
        const sortedKeys = Object.keys(params).sort();
        const base = sortedKeys
            .map(k => `${k}=${params[k]}`)
            .join('&') + `&timestamp=${timestamp}&secret=${OrderKuota.KONCI_RAHASIA}`;
        return crypto.createHmac('sha256', OrderKuota.KONCI_RAHASIA).update(base).digest('hex');
    }

    async request(method, url, postData = null, extraHeaders = []) {
        const headers = {
            'Host': OrderKuota.HOST,
            'User-Agent': OrderKuota.USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip',
            ...extraHeaders.reduce((acc, h) => {
                const [key, ...val] = h.split(': ');
                acc[key] = val.join(': ');
                return acc;
            }, {})
        };

        const config = {
            method: method,
            url: url,
            headers: headers,
            timeout: 30000,
            maxRedirects: 5,
            decompress: true,
        };

        if (postData !== null) {
            config.data = postData;
        }

        try {
            const response = await axios(config);
            return response.data;
        } catch (error) {
            if (error.response) {
                return error.response.data;
            }
            throw error;
        }
    }

    async login(username, password) {
        const requestTime = Date.now();
        const device = this.getDeviceInfo();

        const payload = new URLSearchParams({
            username: username,
            password: password,
            request_time: requestTime,
            app_reg_id: device.app_reg_id,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            phone_uuid: device.phone_uuid,
        }).toString();

        const response = await this.request('POST', OrderKuota.API_URL + '/login', payload);
        return response;
    }

    async generateQr(amount) {
        const requestTime = Date.now();
        const device = this.getDeviceInfo();

        const payload = new URLSearchParams({
            request_time: requestTime,
            app_reg_id: device.app_reg_id,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            phone_uuid: device.phone_uuid,
            auth_username: this.username,
            auth_token: this.authToken,
            'requests[qris_merchant_terms][jumlah]': amount,
            'requests[0]': 'qris_merchant_terms',
            app_version_name: device.app_version_name,
            phone_model: device.phone_model,
        }).toString();

        const response = await this.request('POST', OrderKuota.API_URL + '/get', payload);
        return response;
    }

    async withdraw(amount) {
        const requestTime = Date.now();
        const device = this.getDeviceInfo();

        const payload = new URLSearchParams({
            request_time: requestTime,
            app_reg_id: device.app_reg_id,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            phone_uuid: device.phone_uuid,
            auth_username: this.username,
            auth_token: this.authToken,
            'requests[qris_withdraw][amount]': amount,
            'requests[0]': 'account',
            app_version_name: device.app_version_name,
            ui_mode: 'light',
            phone_model: device.phone_model,
        }).toString();

        const response = await this.request('POST', OrderKuota.API_URL + '/get', payload);
        return response;
    }

    async getTransactionQris() {
        const resellerId = this.authToken.split(':')[0];
        const requestTime = Date.now();
        const device = this.getDeviceInfo();

        const paramsForSign = {
            auth_username: this.username,
            auth_token: this.authToken,
            phone_uuid: device.phone_uuid,
            request_time: requestTime,
        };
        const signature = this.generateSignature(paramsForSign, requestTime);

        const payload = new URLSearchParams({
            app_reg_id: device.app_reg_id,
            phone_uuid: device.phone_uuid,
            phone_model: device.phone_model,
            'requests[qris_history][keterangan]': '',
            'requests[qris_history][jumlah]': '',
            'requests[qris_history][jenis]': '1',
            request_time: requestTime,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            auth_username: this.username,
            'requests[qris_history][page]': '1',
            auth_token: this.authToken,
            app_version_name: device.app_version_name,
            ui_mode: 'light',
            'requests[qris_history][dari_tanggal]': '',
            'requests[0]': 'account',
            'requests[qris_history][ke_tanggal]': '',
        }).toString();

        const extraHeaders = [
            `signature: ${signature}`,
            `timestamp: ${requestTime}`,
        ];

        const url = OrderKuota.API_URL + '/qris/mutasi/' + resellerId;
        const response = await this.request('POST', url, payload, extraHeaders);
        return response;
    }

    async getProfile() {
        const requestTime = Date.now();
        const device = this.getDeviceInfo();

        const paramsForSign = {
            auth_username: this.username,
            auth_token: this.authToken,
            phone_uuid: device.phone_uuid,
            request_time: requestTime,
        };
        const signature = this.generateSignature(paramsForSign, requestTime);

        const payload = new URLSearchParams({
            app_reg_id: device.app_reg_id,
            phone_uuid: device.phone_uuid,
            phone_model: device.phone_model,
            request_time: requestTime,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            auth_username: this.username,
            'requests[2]': 'home_toolbar_button',
            'requests[1]': 'point',
            'requests[0]': 'account',
            auth_token: this.authToken,
            app_version_name: device.app_version_name,
            ui_mode: 'light',
        }).toString();

        const extraHeaders = [
            `signature: ${signature}`,
            `timestamp: ${requestTime}`,
        ];

        const url = OrderKuota.API_URL + '/get';
        const response = await this.request('POST', url, payload, extraHeaders);
        return response;
    }

    static async cekEwallet(provider, nomor, username, token) {
        const validProviders = ['dana', 'ovo', 'gopay', 'shopeepay', 'linkaja'];
        if (!validProviders.includes(provider)) {
            return {
                status: false,
                error: 'Provider tidak valid',
                valid_providers: validProviders
            };
        }

        const orderkuota = new OrderKuota();
        const device = orderkuota.getDeviceInfo();
        const timestamp = Date.now();

        const payload = new URLSearchParams({
            app_reg_id: device.app_reg_id,
            phone_uuid: device.phone_uuid,
            phone_model: device.phone_model,
            phoneNumber: nomor,
            request_time: timestamp,
            phone_android_version: device.phone_android_version,
            app_version_code: device.app_version_code,
            auth_username: username,
            customerId: '',
            id: provider,
            auth_token: token,
            app_version_name: device.app_version_name,
            ui_mode: 'dark',
        }).toString();

        const url = 'https://checker.orderkuota.com/api/checkname/produk/5db26e7b429d49106145635bf5f0436f8c1f43323b/25/2088243/dana?phone=083164465401&cust_id=&b=0&t=f746e94f';

        try {
            const response = await axios({
                method: 'POST',
                url: url,
                data: payload,
                headers: {
                    'User-Agent': 'okhttp/4.12.0',
                    'Accept-Encoding': 'gzip',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'signature': '63c7cce025a219cf50ad08513d2a669e1c7bacf3233e42810aa42ced97eca2e6c6a926afd5afd93eb2fd90854e045d12921a2c84049f8096f4ec2b849097e940',
                    'timestamp': timestamp,
                },
                timeout: 30000,
                decompress: true,
            });
            return { status: true, result: response.data };
        } catch (error) {
            return {
                status: false,
                error: error.response ? `HTTP ${error.response.status}` : error.message,
                raw: error.response ? error.response.data : null
            };
        }
    }
}

module.exports = OrderKuota;