require('dotenv').config();
const express = require('express');
const axios = require('axios');
const crypto = require('crypto');
const FormData = require('form-data');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const rateLimit = require('express-rate-limit');
const NodeCache = require('node-cache');
const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');

const app = express();
const PORT = process.env.PORT || 3000;

// ==================== TELEGRAM BOT ====================
const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN || '8935907671:AAHDhXYbegMAucxy0Dv5VnBmf9D6ZpnUFp0';
const TELEGRAM_OWNER_ID = process.env.TELEGRAM_OWNER_ID || '8038424443';

let bot = null;
try {
    bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });
    console.log('🤖 Telegram Bot started!');
} catch (error) {
    console.log('⚠️ Telegram Bot error:', error.message);
}

// ==================== MIDDLEWARE ====================
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Too many requests, please try again later.',
});
app.use('/api', limiter);

// ==================== VIEW ENGINE ====================
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ==================== KONFIGURASI ====================
const VALID_API_KEYS = ['Azxx', 'Lyyncode', 'Time160110', 'luxzz02', 'KhafaCode'];
const KONCI_RAHASIA = 'orderkuota_mobile_app_2024';
const API_URL = 'https://app.orderkuota.com/api/v2';

// ==================== CACHE & DATA STORAGE ====================
const mutasiCache = new NodeCache({ stdTTL: 300 });
const DATA_FILE = path.join(__dirname, 'data.json');

// Fungsi baca/simpan data
function getStoredData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
        }
    } catch (e) {}
    return { lastTrxId: null, transactions: [], notifiedIds: [] };
}

function saveStoredData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

let storedData = getStoredData();

// ==================== TELEGRAM NOTIFICATION FUNCTION ====================
async function sendTelegramNotification(message, parseMode = 'HTML') {
    if (!bot) {
        console.log('⚠️ Bot not initialized');
        return false;
    }
    
    try {
        await bot.sendMessage(TELEGRAM_OWNER_ID, message, { parseMode });
        console.log('✅ Telegram notification sent');
        return true;
    } catch (error) {
        console.log('❌ Telegram error:', error.message);
        return false;
    }
}

// ==================== TELEGRAM BOT COMMANDS ====================
if (bot) {
    // Command: /start
    bot.onText(/\/start/, async (msg) => {
        const chatId = msg.chat.id;
        const welcome = `
🚀 <b>AZX Gateway Bot</b>

Halo! Saya adalah bot notifikasi untuk AZX Gateway.

<b>📋 Available Commands:</b>
/start - Tampilkan pesan ini
/status - Cek status sistem
/check - Cek ada transaksi baru (manual)
/reset - Reset data mutasi

<b>⚡ Features:</b>
• Notifikasi otomatis saat ada transaksi baru
• Monitoring mutasi real-time
• Cek status sistem
        `;
        await bot.sendMessage(chatId, welcome, { parseMode: 'HTML' });
    });

    // Command: /status
    bot.onText(/\/status/, async (msg) => {
        const chatId = msg.chat.id;
        const status = `
📊 <b>System Status</b>

🟢 Status: <b>Operational</b>
📦 Cache: ${mutasiCache.keys().length} item
💾 Last Transaction: ${storedData.lastTrxId || 'Belum ada'}
📝 Total Transactions: ${storedData.transactions?.length || 0}
⏰ Server Time: ${new Date().toLocaleString('id-ID')}
        `;
        await bot.sendMessage(chatId, status, { parseMode: 'HTML' });
    });

    // Command: /reset
    bot.onText(/\/reset/, async (msg) => {
        const chatId = msg.chat.id;
        storedData.lastTrxId = null;
        storedData.transactions = [];
        storedData.notifiedIds = [];
        saveStoredData(storedData);
        mutasiCache.flushAll();
        await bot.sendMessage(chatId, '✅ Data mutasi telah di-reset!', { parseMode: 'HTML' });
    });
}

// ==================== ORDERKUOTA CLASS ====================
class OrderKuota {
    constructor(username = null, authToken = null) {
        this.API_URL = API_URL;
        this.HOST = 'app.orderkuota.com';
        this.USER_AGENT = 'okhttp/4.12.0';
        this.username = username;
        this.authToken = authToken;
        this.generateDeviceFingerprint();
    }

    generateDeviceFingerprint() {
        const models = ['SM-G973F', 'SM-N975F', 'SM-A515F'];
        const versions = ['15', '14', '13'];
        const appVersions = ['260115', '260114', '260113'];
        const appNames = ['26.01.15', '26.01.14', '26.01.13'];

        const rawUuid = crypto.randomBytes(16).toString('hex');
        this.phoneUuid = `${rawUuid.slice(0,8)}-${rawUuid.slice(8,12)}-${rawUuid.slice(12,16)}-${rawUuid.slice(16,20)}-${rawUuid.slice(20,32)}`;
        
        const fcmHash = crypto.createHash('sha256').update(crypto.randomBytes(16)).digest('hex');
        this.appRegId = `${this.phoneUuid}:APA91b${fcmHash.slice(0,100)}`;
        
        this.phoneModel = models[Math.floor(Math.random() * models.length)];
        this.phoneAndroidVersion = versions[Math.floor(Math.random() * versions.length)];
        const idx = Math.floor(Math.random() * appVersions.length);
        this.appVersionCode = appVersions[idx];
        this.appVersionName = appNames[idx];
    }

    getDevice() {
        return {
            app_reg_id: this.appRegId,
            phone_uuid: this.phoneUuid,
            phone_model: this.phoneModel,
            phone_android_version: this.phoneAndroidVersion,
            app_version_code: this.appVersionCode,
            app_version_name: this.appVersionName,
        };
    }

    generateSignature(params, timestamp) {
        const sorted = Object.keys(params).sort();
        let base = sorted.map(k => `${k}=${params[k]}`).join('&');
        base += `&timestamp=${timestamp}&secret=${KONCI_RAHASIA}`;
        return crypto.createHmac('sha256', KONCI_RAHASIA).update(base).digest('hex');
    }

    async request(method, url, data = null, extraHeaders = []) {
        const headers = {
            'Host': this.HOST,
            'User-Agent': this.USER_AGENT,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Encoding': 'gzip',
        };
        
        extraHeaders.forEach(h => {
            const [key, val] = h.split(': ');
            headers[key] = val;
        });

        const config = { method, url, headers, timeout: 30000 };
        if (data) config.data = data;

        try {
            const response = await axios(config);
            return response.data;
        } catch (error) {
            if (error.response) return error.response.data;
            return { error: error.message };
        }
    }

    async login(username, password) {
        const ts = Date.now();
        const d = this.getDevice();
        const payload = new URLSearchParams({
            username, password,
            request_time: ts,
            app_reg_id: d.app_reg_id,
            phone_android_version: d.phone_android_version,
            app_version_code: d.app_version_code,
            phone_uuid: d.phone_uuid,
        });

        return await this.request('POST', `${this.API_URL}/login`, payload.toString());
    }

    async generateQr(amount) {
        const ts = Date.now();
        const d = this.getDevice();
        const payload = new URLSearchParams({
            request_time: ts,
            app_reg_id: d.app_reg_id,
            phone_android_version: d.phone_android_version,
            app_version_code: d.app_version_code,
            phone_uuid: d.phone_uuid,
            auth_username: this.username,
            auth_token: this.authToken,
            'requests[qris_merchant_terms][jumlah]': amount,
            'requests[0]': 'qris_merchant_terms',
            app_version_name: d.app_version_name,
            phone_model: d.phone_model,
        });

        const response = await this.request('POST', `${this.API_URL}/get`, payload.toString());
        if (response.success && response.qris_merchant_terms?.results) {
            return response.qris_merchant_terms.results;
        }
        return response;
    }

    async withdraw(amount) {
        const ts = Date.now();
        const d = this.getDevice();
        const payload = new URLSearchParams({
            request_time: ts,
            app_reg_id: d.app_reg_id,
            phone_android_version: d.phone_android_version,
            app_version_code: d.app_version_code,
            phone_uuid: d.phone_uuid,
            auth_username: this.username,
            auth_token: this.authToken,
            'requests[qris_withdraw][amount]': amount,
            'requests[0]': 'account',
            app_version_name: d.app_version_name,
            ui_mode: 'light',
            phone_model: d.phone_model,
        });

        return await this.request('POST', `${this.API_URL}/get`, payload.toString());
    }

    async getTransactionQris() {
        const resellerId = this.authToken.split(':')[0];
        const ts = Date.now();
        const d = this.getDevice();

        const params = {
            auth_username: this.username,
            auth_token: this.authToken,
            phone_uuid: d.phone_uuid,
            request_time: ts,
        };
        const signature = this.generateSignature(params, ts);

        const payload = new URLSearchParams({
            app_reg_id: d.app_reg_id,
            phone_uuid: d.phone_uuid,
            phone_model: d.phone_model,
            'requests[qris_history][keterangan]': '',
            'requests[qris_history][jumlah]': '',
            'requests[qris_history][jenis]': '1',
            request_time: ts,
            phone_android_version: d.phone_android_version,
            app_version_code: d.app_version_code,
            auth_username: this.username,
            'requests[qris_history][page]': '1',
            auth_token: this.authToken,
            app_version_name: d.app_version_name,
            ui_mode: 'light',
            'requests[qris_history][dari_tanggal]': '',
            'requests[0]': 'account',
            'requests[qris_history][ke_tanggal]': '',
        });

        const extra = [`signature: ${signature}`, `timestamp: ${ts}`];
        const url = `${this.API_URL}/qris/mutasi/${resellerId}`;
        return await this.request('POST', url, payload.toString(), extra);
    }

    async getProfile() {
        const ts = Date.now();
        const d = this.getDevice();

        const params = {
            auth_username: this.username,
            auth_token: this.authToken,
            phone_uuid: d.phone_uuid,
            request_time: ts,
        };
        const signature = this.generateSignature(params, ts);

        const payload = new URLSearchParams({
            app_reg_id: d.app_reg_id,
            phone_uuid: d.phone_uuid,
            phone_model: d.phone_model,
            request_time: ts,
            phone_android_version: d.phone_android_version,
            app_version_code: d.app_version_code,
            auth_username: this.username,
            'requests[2]': 'home_toolbar_button',
            'requests[1]': 'point',
            'requests[0]': 'account',
            auth_token: this.authToken,
            app_version_name: d.app_version_name,
            ui_mode: 'light',
        });

        const extra = [`signature: ${signature}`, `timestamp: ${ts}`];
        return await this.request('POST', `${this.API_URL}/get`, payload.toString(), extra);
    }
}

// ==================== HELPER FUNCTIONS ====================
function convertCRC16(str) {
    let crc = 0xFFFF;
    for (let c = 0; c < str.length; c++) {
        crc ^= str.charCodeAt(c) << 8;
        for (let i = 0; i < 8; i++) {
            crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : crc << 1;
        }
    }
    return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
}

function generateTransactionId() {
    return `AZX-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function generateExpirationTime() {
    const exp = new Date();
    exp.setMinutes(exp.getMinutes() + 30);
    return exp.toISOString().replace('T', ' ').slice(0, 19);
}

async function uploadToPixhost(buffer) {
    const form = new FormData();
    form.append('content_type', '0');
    form.append('img', buffer, { filename: 'qris.png', contentType: 'image/png' });

    const res = await axios.post('https://api.pixhost.to/images', form, {
        headers: { ...form.getHeaders(), 'User-Agent': 'Mozilla/5.0' },
        timeout: 30000,
    });

    if (res.data?.show_url) {
        const html = await axios.get(res.data.show_url, { timeout: 15000 });
        const match = html.data.match(/<img[^>]+class="image-img"[^>]+src="([^"]+)"/i);
        if (match) {
            let url = match[1];
            if (url.startsWith('//')) url = `https:${url}`;
            return url;
        }
    }
    throw new Error('Pixhost gagal');
}

async function uploadToUploadCC(buffer) {
    const form = new FormData();
    form.append('uploaded_file[]', buffer, { filename: 'qris.png', contentType: 'image/png' });

    const res = await axios.post('https://upload.cc/image_upload', form, {
        headers: { ...form.getHeaders(), 'Referer': 'https://upload.cc' },
        timeout: 30000,
    });

    if (res.data?.code === 100 && res.data?.success_image?.[0]) {
        return `https://upload.cc/${res.data.success_image[0].url.replace(/^\//, '')}`;
    }
    throw new Error('UploadCC gagal');
}

async function uploadImage(buffer) {
    const errors = [];
    for (const uploader of [uploadToPixhost, uploadToUploadCC]) {
        try { return await uploader(buffer); } 
        catch (e) { errors.push(e.message); }
    }
    throw new Error(`Upload gagal: ${errors.join(' | ')}`);
}

async function createQRIS(amount, qrisString) {
    const qrisData = qrisString.slice(0, -4);
    const step1 = qrisData.replace('010211', '010212');
    const step2 = step1.split('5802ID');
    const uang = `54${String(amount).length.toString().padStart(2, '0')}${amount}5802ID`;
    const final = `${step2[0]}${uang}${step2[1]}`;
    const result = final + convertCRC16(final);

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=25&data=${encodeURIComponent(result)}`;
    const response = await axios.get(qrUrl, { responseType: 'arraybuffer', timeout: 15000 });
    const imageUrl = await uploadImage(Buffer.from(response.data));

    return {
        idtransaksi: generateTransactionId(),
        jumlah: amount,
        expired: generateExpirationTime(),
        imageqris: { url: imageUrl },
        qr_string: result,
    };
}

// ==================== ROUTES ====================

// DASHBOARD PAGE (Main Landing)
app.get('/', (req, res) => {
    res.render('dashboard', {
        title: 'AZX Gateway - Payment Gateway',
        currentYear: new Date().getFullYear(),
    });
});

// HOME PAGE (API Documentation)
app.get('/docs', (req, res) => {
    res.render('home', {
        title: 'AZX Gateway - API Documentation',
        currentYear: new Date().getFullYear(),
        actions: ['getotp', 'gettoken', 'createpayment', 'mutasiqr', 'cekprofile', 'wdqr', 'cekewallet', 'checknew']
    });
});

// ==================== API ENDPOINTS ====================
app.get('/api', async (req, res) => {
    try {
        const { action, apikey, username, password, token, amount, otp, provider, nomor } = req.query;

        if (!VALID_API_KEYS.includes(apikey)) {
            return res.status(400).json({ status: false, message: 'API Key tidak valid.' });
        }

        switch (action) {
            case 'getotp': {
                if (!username || !password) {
                    return res.status(400).json({ status: false, message: 'Username & password required' });
                }
                const ok = new OrderKuota();
                const result = await ok.login(username, password);
                return res.json({ status: true, action: 'getotp', result });
            }

            case 'gettoken': {
                if (!username || !otp) {
                    return res.status(400).json({ status: false, message: 'Username & otp required' });
                }
                const ok = new OrderKuota();
                const result = await ok.login(username, otp);
                return res.json({ status: true, action: 'gettoken', result });
            }

            case 'createpayment': {
                if (!username || !token) {
                    return res.status(400).json({ status: false, message: 'Username & token required' });
                }
                const amt = parseInt(amount) || 0;
                if (amt <= 0) {
                    return res.status(400).json({ status: false, message: 'Amount must be > 0' });
                }
                
                const ok = new OrderKuota(username, token);
                const qr = await ok.generateQr(amt);
                if (!qr.qris_data) {
                    return res.status(500).json({ status: false, message: 'QRIS failed', detail: qr });
                }
                
                const result = await createQRIS(amt, qr.qris_data);
                return res.json({
                    status: true,
                    action: 'createpayment',
                    result: {
                        trxid: result.idtransaksi,
                        nominal: result.jumlah,
                        expired: result.expired,
                        qris_image: result.imageqris.url,
                        qris_string: result.qr_string,
                    }
                });
            }

            case 'mutasiqr': {
                if (!username || !token) {
                    return res.status(400).json({ status: false, message: 'Username & token required' });
                }

                const cacheKey = `mutasi_${username}_${token}`;
                const cached = mutasiCache.get(cacheKey);

                // Cek cache dulu
                if (cached) {
                    const lastId = storedData.lastTrxId || '';
                    const newTransactions = cached.filter(t => t.id !== lastId);
                    
                    // Update jika ada transaksi baru
                    if (newTransactions.length > 0 && !storedData.notifiedIds?.includes(newTransactions[0]?.id)) {
                        // Kirim notifikasi Telegram
                        const trx = newTransactions[0];
                        const msg = `
💳 <b>Transaksi Baru!</b>

🆔 ID: <code>${trx.id || 'N/A'}</code>
💰 Nominal: <b>Rp ${Number(trx.amount || trx.nominal || 0).toLocaleString()}</b>
📅 Tanggal: ${trx.date || trx.tanggal || new Date().toLocaleString('id-ID')}
👤 Username: <code>${username}</code>
⏰ Waktu: ${new Date().toLocaleString('id-ID')}

━━━━━━━━━━━━━━━━━━━━
🔔 <b>Notifikasi dari AZX Gateway</b>
                        `;
                        await sendTelegramNotification(msg);
                        
                        // Update notifiedIds
                        if (!storedData.notifiedIds) storedData.notifiedIds = [];
                        storedData.notifiedIds.push(newTransactions[0].id);
                        storedData.lastTrxId = newTransactions[0].id;
                        saveStoredData(storedData);
                    }

                    return res.json({
                        status: true,
                        action: 'mutasiqr',
                        has_new_transaction: newTransactions.length > 0,
                        message: newTransactions.length > 0 
                            ? `🆕 Ada ${newTransactions.length} transaksi baru! (Notifikasi sudah dikirim ke Telegram)` 
                            : '✅ Tidak ada transaksi baru',
                        data: cached,
                        new_transactions: newTransactions,
                        last_transaction_id: storedData.lastTrxId || 'Belum ada transaksi'
                    });
                }

                // Ambil dari OrderKuota
                try {
                    const ok = new OrderKuota(username, token);
                    const result = await ok.getTransactionQris();

                    const resultStr = JSON.stringify(result);
                    if (resultStr.includes('terlalu banyak') || resultStr.includes('too many')) {
                        return res.json({
                            status: false,
                            action: 'mutasiqr',
                            message: '⚠️ Rate limit: terlalu banyak request. Tunggu 5 menit.',
                            wait_time: 300,
                        });
                    }

                    const data = result.qris_history || result;

                    if (data && !data.error) {
                        mutasiCache.set(cacheKey, data);

                        const lastId = storedData.lastTrxId || '';
                        const newTransactions = data.filter(t => t.id !== lastId);

                        // Kirim notifikasi jika ada transaksi baru
                        if (newTransactions.length > 0) {
                            // Notifikasi per transaksi
                            for (const trx of newTransactions) {
                                if (!storedData.notifiedIds?.includes(trx.id)) {
                                    const msg = `
💳 <b>Transaksi Baru!</b>

🆔 ID: <code>${trx.id || 'N/A'}</code>
💰 Nominal: <b>Rp ${Number(trx.amount || trx.nominal || 0).toLocaleString()}</b>
📅 Tanggal: ${trx.date || trx.tanggal || new Date().toLocaleString('id-ID')}
👤 Username: <code>${username}</code>
⏰ Waktu: ${new Date().toLocaleString('id-ID')}

━━━━━━━━━━━━━━━━━━━━
🔔 <b>Notifikasi dari AZX Gateway</b>
                                    `;
                                    await sendTelegramNotification(msg);
                                    
                                    if (!storedData.notifiedIds) storedData.notifiedIds = [];
                                    storedData.notifiedIds.push(trx.id);
                                }
                            }

                            // Update last transaction ID
                            storedData.lastTrxId = data[0]?.id || lastId;
                            storedData.transactions = data;
                            saveStoredData(storedData);
                        }

                        return res.json({
                            status: true,
                            action: 'mutasiqr',
                            has_new_transaction: newTransactions.length > 0,
                            message: newTransactions.length > 0 
                                ? `🆕 Ada ${newTransactions.length} transaksi baru! (Notifikasi sudah dikirim ke Telegram)` 
                                : '✅ Tidak ada transaksi baru',
                            data: data,
                            new_transactions: newTransactions,
                            last_transaction_id: storedData.lastTrxId || 'Belum ada transaksi'
                        });
                    }

                    return res.json({ status: true, action: 'mutasiqr', result: data });
                } catch (error) {
                    return res.json({
                        status: false,
                        action: 'mutasiqr',
                        message: error.message
                    });
                }
            }

            case 'checknew': {
                if (!username || !token) {
                    return res.status(400).json({ 
                        status: false, 
                        message: 'Username & token required' 
                    });
                }

                const cacheKey = `mutasi_${username}_${token}`;
                const cached = mutasiCache.get(cacheKey);

                if (!cached) {
                    return res.json({
                        status: false,
                        action: 'checknew',
                        message: '⚠️ Belum ada data mutasi. Cek mutasi dulu (action=mutasiqr)',
                        need_full_check: true
                    });
                }

                const lastId = storedData.lastTrxId || '';
                const newTransactions = cached.filter(t => t.id !== lastId);

                return res.json({
                    status: true,
                    action: 'checknew',
                    has_new_transaction: newTransactions.length > 0,
                    message: newTransactions.length > 0 
                        ? `🆕 Ada ${newTransactions.length} transaksi baru!` 
                        : '✅ Tidak ada transaksi baru',
                    new_count: newTransactions.length,
                    last_transaction_id: lastId || 'Belum ada transaksi'
                });
            }

            case 'cekprofile': {
                if (!username || !token) {
                    return res.status(400).json({ status: false, message: 'Username & token required' });
                }
                const ok = new OrderKuota(username, token);
                const result = await ok.getProfile();
                return res.json({ status: true, action: 'cekprofile', result: result.account?.results || result });
            }

            case 'wdqr': {
                if (!username || !token) {
                    return res.status(400).json({ status: false, message: 'Username & token required' });
                }
                const amt = parseInt(amount) || 0;
                if (amt <= 0) {
                    return res.status(400).json({ status: false, message: 'Amount must be > 0' });
                }
                const ok = new OrderKuota(username, token);
                const result = await ok.withdraw(amt);

                // Notifikasi withdraw
                if (result.success) {
                    const msg = `
🏦 <b>Withdraw QRIS!</b>

👤 Username: <code>${username}</code>
💰 Nominal: <b>Rp ${amt.toLocaleString()}</b>
⏰ Waktu: ${new Date().toLocaleString('id-ID')}
📊 Status: <b>✅ Berhasil</b>

━━━━━━━━━━━━━━━━━━━━
🔔 <b>Notifikasi dari AZX Gateway</b>
                    `;
                    await sendTelegramNotification(msg);
                }

                return res.json({ status: true, action: 'wdqr', result });
            }

            case 'resetmutasi': {
                if (!username) {
                    return res.status(400).json({ 
                        status: false, 
                        message: 'Username required' 
                    });
                }

                storedData.lastTrxId = null;
                storedData.transactions = [];
                storedData.notifiedIds = [];
                saveStoredData(storedData);

                const keys = mutasiCache.keys();
                keys.forEach(key => {
                    if (key.includes(username)) {
                        mutasiCache.del(key);
                    }
                });

                // Notifikasi reset
                const msg = `
🔄 <b>Reset Data Mutasi!</b>

👤 Username: <code>${username}</code>
⏰ Waktu: ${new Date().toLocaleString('id-ID')}

━━━━━━━━━━━━━━━━━━━━
🔔 <b>Notifikasi dari AZX Gateway</b>
                `;
                await sendTelegramNotification(msg);

                return res.json({
                    status: true,
                    action: 'resetmutasi',
                    message: '✅ Data mutasi telah di-reset. Silakan cek mutasi lagi.'
                });
            }

            case 'cekewallet': {
                if (!provider || !nomor || !username || !token) {
                    return res.status(400).json({ 
                        status: false, 
                        message: 'Provider, nomor, username, token required' 
                    });
                }

                const valid = ['dana', 'ovo', 'gopay', 'shopeepay', 'linkaja'];
                if (!valid.includes(provider.toLowerCase())) {
                    return res.json({
                        status: false,
                        error: 'Provider tidak valid',
                        valid_providers: valid
                    });
                }

                const ok = new OrderKuota();
                const d = ok.getDevice();
                const ts = Date.now();

                const payload = new URLSearchParams({
                    app_reg_id: d.app_reg_id,
                    phone_uuid: d.phone_uuid,
                    phone_model: d.phone_model,
                    phoneNumber: nomor,
                    request_time: ts,
                    phone_android_version: d.phone_android_version,
                    app_version_code: d.app_version_code,
                    auth_username: username,
                    customerId: '',
                    id: provider.toLowerCase(),
                    auth_token: token,
                    app_version_name: d.app_version_name,
                    ui_mode: 'dark'
                });

                const url = 'https://checker.orderkuota.com/api/checkname/produk/5db26e7b429d49106145635bf5f0436f8c1f43323b/25/2088243/dana?phone=083164465401&cust_id=&b=0&t=f746e94f';

                const response = await axios.post(url, payload.toString(), {
                    headers: {
                        'User-Agent': 'okhttp/4.12.0',
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'signature': '63c7cce025a219cf50ad08513d2a669e1c7bacf3233e42810aa42ced97eca2e6c6a926afd5afd93eb2fd90854e045d12921a2c84049f8096f4ec2b849097e940',
                        'timestamp': ts,
                    },
                    timeout: 30000,
                });

                return res.json({ status: true, result: response.data });
            }

            default: {
                return res.status(400).json({
                    status: false,
                    message: 'Action tidak valid. Gunakan: getotp, gettoken, createpayment, mutasiqr, cekprofile, wdqr, cekewallet, checknew, resetmutasi.'
                });
            }
        }
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error.message,
        });
    }
});

// 404 Handler
app.use((req, res) => {
    res.status(404).json({ status: false, message: 'Endpoint not found' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 AZX Gateway running on port ${PORT}`);
    console.log(`📡 http://localhost:${PORT}`);
    console.log(`📡 API: http://localhost:${PORT}/api`);
    console.log(`🤖 Telegram Bot: ${bot ? '✅ Active' : '❌ Inactive'}`);
    console.log(`🔑 Valid API Keys: ${VALID_API_KEYS.join(', ')}`);
});